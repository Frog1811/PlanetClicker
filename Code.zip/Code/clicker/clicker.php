<?php require_once(__DIR__.'/../config.php');?>

<script src="<?php global $baseurl; echo $baseurl; ?>clicker/clicker.js">
</script>
<script src="main.js"></script>



