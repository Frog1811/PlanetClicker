<?php
$baseurl = "/Planetclicker/Code/"
?>