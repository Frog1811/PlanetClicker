class Upgrade {
    CPS;
    type;
    owned;
    power;
    price;


    constructor(CPS, type, owned, power, price) {
        this.CPS = CPS;
        this.type = type
        this.owned = owned;
        this.power = power;
        this.price = price;
    }

}